import React from "react";

function FiltersSidebar({ filters, setFilters }) {
  const categories = [
    "Pottery", "Woodcraft", "Textiles", "Jewelry",
    "Leatherwork", "Sculptures",
  ];

  const handleCheckboxChange = (category) => {
    const updated = filters.categories.includes(category)
      ? filters.categories.filter((c) => c !== category)
      : [...filters.categories, category];

    setFilters({ ...filters, categories: updated });
  };

  const handleDateChange = (dateFilter) => {
    setFilters({ ...filters, date: dateFilter });
  };

  return (
    <div style={styles.sidebar}>
      <h3 style={styles.heading}>Filters</h3>

      {/* Category */}
      <div style={styles.section}>
        <h4 style={styles.label}>Category</h4>
        {categories.map((cat) => (
          <label key={cat} style={styles.checkbox}>
            <input
              type="checkbox"
              checked={filters.categories.includes(cat)}
              onChange={() => handleCheckboxChange(cat)}
            />
            <span style={{ marginLeft: 8 }}>{cat}</span>
          </label>
        ))}
      </div>

      {/* Price */}
      <div style={styles.section}>
        <h4 style={styles.label}>Price Range</h4>
        <input
          type="range"
          min={0}
          max={500}
          step={10}
          value={filters.price}
          onChange={(e) => setFilters({ ...filters, price: e.target.value })}
          style={styles.range}
        />
        <p>${filters.price}</p>
      </div>

      {/* Date */}
      <div style={styles.section}>
        <h4 style={styles.label}>Date Added</h4>
        {["Last 7 Days", "Last 30 Days", "Last 90 Days", "All Time"].map((d) => (
          <label key={d} style={styles.radio}>
            <input
              type="radio"
              name="date"
              value={d}
              checked={filters.date === d}
              onChange={() => handleDateChange(d)}
            />
            <span style={{ marginLeft: 8 }}>{d}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

const styles = {
  sidebar: {
    width: "240px",
    padding: "20px",
    background: "#f8f1ea",
    borderRight: "1px solid #ddd",
    borderRadius: "8px",
    fontFamily: "serif",
  },
  heading: {
    fontSize: "20px",
    marginBottom: "15px",
    color: "#5b3924",
  },
  section: {
    marginBottom: "20px",
  },
  label: {
    fontSize: "16px",
    fontWeight: "600",
    marginBottom: "10px",
    color: "#3d2b1f",
  },
  checkbox: {
    display: "block",
    margin: "5px 0",
    fontSize: "14px",
  },
  radio: {
    display: "block",
    margin: "5px 0",
    fontSize: "14px",
  },
  range: {
    width: "100%",
    marginTop: "10px",
  },
};

export default FiltersSidebar;
