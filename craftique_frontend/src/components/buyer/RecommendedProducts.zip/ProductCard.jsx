import React from "react";

function ProductCard({ product, onAddToCart, onBuyNow }) {
  const { title, price, image, badge } = product;

  return (
    <div style={styles.card}>
      {/* Image */}
      <div style={styles.imageContainer}>
        {badge && <span style={styles.badge}>{badge}</span>}
        <img
          src={image || "/placeholder.jpg"}
          alt={title}
          style={styles.image}
        />
      </div>

      {/* Details */}
      <div style={styles.details}>
        <h4 style={styles.title}>{title}</h4>
        <p style={styles.price}>${price}</p>

        {/* Buttons */}
        <div style={styles.actions}>
          <button style={styles.button} onClick={() => onAddToCart(product)}>
            Add to Cart
          </button>
          <button
            style={{ ...styles.button, backgroundColor: "#8b5e3c" }}
            onClick={() => onBuyNow(product)}
          >
            Buy Now
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  card: {
    width: "240px",
    border: "1px solid #e0d3c2",
    borderRadius: "8px",
    overflow: "hidden",
    background: "#fffefc",
    boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
    fontFamily: "serif",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  imageContainer: {
    position: "relative",
    height: "200px",
    overflow: "hidden",
    backgroundColor: "#faf7f3",
  },
  image: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
  },
  badge: {
    position: "absolute",
    top: 8,
    left: 8,
    backgroundColor: "#b57f4d",
    color: "#fff",
    fontSize: "12px",
    padding: "3px 8px",
    borderRadius: "4px",
  },
  details: {
    padding: "12px",
  },
  title: {
    fontSize: "16px",
    fontWeight: "600",
    marginBottom: "4px",
    color: "#4b2e1f",
  },
  price: {
    fontSize: "14px",
    color: "#7a5d46",
    marginBottom: "10px",
  },
  actions: {
    display: "flex",
    gap: "6px",
  },
  button: {
    flex: 1,
    padding: "6px 10px",
    fontSize: "14px",
    backgroundColor: "#d4a373",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
};

export default ProductCard;
